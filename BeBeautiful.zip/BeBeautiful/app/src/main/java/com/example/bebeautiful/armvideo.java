package com.example.bebeautiful;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class armvideo extends AppCompatActivity {
    WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_armvideo);
        wv=(WebView)findViewById(R.id.wv);
        wv.loadUrl("https://youtu.be/8QloOp2Vw0U");
    }
}
