package com.example.bebeautiful;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class skin2 extends AppCompatActivity {
    TextView ts1;
    ImageView ims;
    Button b1;
    WebView wv;


    String dis[]={"Mash the papaya and banana so that no lumps remain.Add the honey and mix well.Apply this paste on your face and other dry areas on your body.","Mix 1 egg white,1 teaspoon orange juice,½ teaspoon turmeric powder  in a bowl.Use a brush to apply the paste on your face and neck (avoid the area around your eyes).Leave it on to dry. Gently wash off the mask with water.Use this mask twice a week.."};
    Integer im[]={R.drawable.pappaya,R.drawable.egg};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skin2);
        ts1=(TextView)findViewById(R.id.ts1);
        ims=(ImageView)findViewById(R.id.ims);
        b1=(Button)findViewById(R.id.b1);
        wv=(WebView)findViewById(R.id.wv);
        Intent in=getIntent();
        int a= in.getIntExtra("poss",0);
        String b=in.getStringExtra("name");
        ts1.setText(dis[a]);
        ims.setImageResource(im[a]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Intent in = new Intent(skin2.this, skinvideo.class);
                //startActivity(in);
                wv.loadUrl("https://youtu.be/s6VvxUKRuwg");
            }
        });
    }
}
