package com.example.bebeautiful;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class face2 extends AppCompatActivity {
    TextView tf1;
    ImageView imf;
    Button b1;
    WebView wv;


    String dis[] = {"  Take the honey in a bowl. Add the turmeric and lemon juice to it.Blend well and massage on your face.Apply evenly and let it sit for 10 minutes.Wash with cold water.", " Whisk the egg whites till they are totally frothy.Put some lemon juice and mix well.Apply this mixture evenly all over the nose.Allow it to dry. Place a clean tissue over it.Apply another layer of the mix on the tissue and let it dry.You can apply a third layer also in case the problem of blackheads is acute.Once dried, gently pull off all the layers of the tissue along with the nose blackheads.Wash the face properly using warm water to neutralise the raw egg smell.", " Clean the affected area and pat it dry.Put 3 drops lemon essential oil drops on the cotton ball and apply on affected area directly.", " Fresh aloe (preferably from the plant) should be rubbed on the dark spot and left for about an hour. Rinse this off with cold water and repeat twice a day for a month."};
    Integer im[] = {R.drawable.turmeric, R.drawable.egg, R.drawable.lemon4, R.drawable.aloe};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face2);
        tf1 = (TextView) findViewById(R.id.tf1);
        imf = (ImageView) findViewById(R.id.imf);
        b1 = (Button) findViewById(R.id.b1);
        wv=(WebView)findViewById(R.id.wv);
        Intent in = getIntent();
        int a = in.getIntExtra("poss", 0);
        String b = in.getStringExtra("name");
        tf1.setText(dis[a]);
        imf.setImageResource(im[a]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wv.loadUrl("https://youtu.be/8QloOp2Vw0U");
                //Intent in = new Intent(face2.this, facevideo.class);
                //startActivity(in);
            }
            });
    }

}

