package com.example.bebeautiful;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class hair extends AppCompatActivity {
    ListView hairlist;
    String hair[] = {"Dandruff Removing", "Hair Falling", "Hair Damage", "Long Thick Hair"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hair);
        hairlist = (ListView) findViewById(R.id.hairlist);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, hair);
        hairlist.setAdapter(adapter);
        hairlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent in = new Intent(hair.this, hair2.class);

                in.putExtra("poss", position);
                in.putExtra("name", hair[position]);
                startActivity(in);
            }
        });
    }
}