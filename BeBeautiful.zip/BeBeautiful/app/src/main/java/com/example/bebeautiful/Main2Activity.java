package com.example.bebeautiful;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    ListView facelist;

    String face[]={"Glowing Face","Removing Blackheads","Removing Pimples","Removing Darkspots"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        facelist=(ListView) findViewById(R.id.facelist);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,face);
        facelist.setAdapter(adapter);
        facelist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent in = new Intent(Main2Activity.this, face2.class);

                in.putExtra("poss",position);
                in.putExtra("name",face[position]);

                startActivity(in);
            }
        });


    }
}
