package com.example.bebeautiful;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class hair2 extends AppCompatActivity {
    TextView th1;
    ImageView imh;
    Button b1;
    WebView wv;
    String dis[]={" Crush the garlic cloves and mix it with honey till you get a smooth paste.Massage this paste into your scalp and leave it on for about 15 minutes.Shampoo your hair as usual."," Extract the pulp content from the leaf or stalk of aloe and rub into your hair.Ensure your hair is already washed before you do this.Massage the pulp into your scalp in circular motions.Leave it on for about 15 minutes, and then rinse with cold water."," Heat 8 to 10 hibiscus flowers in 1 cup of coconut oil until charred. Strain, allow it to cool and then use it as hair oil. Massage this oil on your hair for a few minutes and leave it on for at least 30 minutes before washing your hair. Alternatively, grind 3 or 4 hibiscus leaves and the petals of 2 hibiscus flower with a little water. Apply it all over your hair, leave it on for 20 minutes and then rinse it off with lukewarm water.Repeat either of these remedies once or twice a week for best results."," Mash a ripe banana until it is completely free of lumps.Apply the mashed banana to your hair and leave it in for 45 minutes to an hour.Wash it off with cool/lukewarm water and a mild shampoo."};
 int im[]={R.drawable.garlic,R.drawable.aloe,R.drawable.hibiscus,R.drawable.banana};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hair2);
        th1=(TextView)findViewById(R.id.th1);
        wv=(WebView)findViewById(R.id.wv);
        imh=(ImageView)findViewById(R.id.imh);
        //wv.loadUrl("http://www.youtube.com");
        b1=(Button)findViewById(R.id.b1);
        Intent in=getIntent();
        int a= in.getIntExtra("poss",0);
        String b= in.getStringExtra("name");
        th1.setText(dis[a]);
        imh.setImageResource(im[a]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent in = new Intent(hair2.this, hairvideo.class);
                //startActivity(in);
                wv.loadUrl("https://youtu.be/JT7fGsq5QHM");
            }
        });

    }
}
