 package com.example.bebeautiful;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class arms extends AppCompatActivity {
    ListView armlist;
    String arm[]={"Dark Elbows and Kness Care","Rough Palm Care ","Rough Hand and Feet Care"};
    //    //Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arms);
        armlist =(ListView) findViewById(R.id.armlist);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arm);
        armlist.setAdapter(adapter);
        armlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent in = new Intent(arms.this, arm2.class);

                in.putExtra("poss",position);
                in.putExtra("name",arm[position]);
                startActivity(in);
             }
        });

        //b1=(Button)findViewById(R.id.button1);
       // b2=(Button)findViewById(R.id.button2);
        //b3=(Button)findViewById(R.id.button3);
        //b4=(Button)findViewById(R.id.button4);
        //b1.setOnClickListener(new View.OnClickListener() {
          //  @Override
            //public void onClick(View v) {
              //  Intent in=new Intent(arms.this,Main2Activity.class);
                //startActivity(in);
            //}
        //});
        //b2.setOnClickListener(new View.OnClickListener() {
          //  @Override
            //public void onClick(View v) {
              //  Intent in=new Intent(arms.this,skin.class);
                //startActivity(in);
            //}
        //});
        //b3.setOnClickListener(new View.OnClickListener() {
         //   @Override
           // public void onClick(View v) {
             //   Intent in=new Intent(arms.this,hair.class);
               // startActivity(in);
            //}
        //});
        //b4.setOnClickListener(new View.OnClickListener() {
          //  @Override
            //public void onClick(View v) {
              //  Intent in=new Intent(arms.this,arms.class);
                //startActivity(in);
            //}
        //});

    }
}
