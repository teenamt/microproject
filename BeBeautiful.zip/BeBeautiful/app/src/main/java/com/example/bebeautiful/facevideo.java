package com.example.bebeautiful;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class facevideo extends AppCompatActivity {
    WebView w;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facevideo);
        w=(WebView)findViewById(R.id.wv);
        w.loadUrl("https://youtu.be/8QloOp2Vw0U");
    }
}
