package com.example.bebeautiful;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class arm2 extends AppCompatActivity {
    TextView ta1;
    ImageView ima;
    Button b1;
    WebView wv;


    String dis[]={" Squeeze the juice of one lemon into a bowl. Add a tablespoon each of sugar and honey to it. Mix well and scrub your elbows and knees gently using this mixture. Leave it on your skin for about 20 minutes before washing it off with lukewarm water.You can do this once every alternate day."," Apply lemon and sugar. Take a 1/2 slice of a lemon. Sprinkle a little sugar on the moist fruit. Squeeze the sugared lemon slice into your hand until the sugar seems completely gone. Repeat with your other hand."," Soaking your feet in warm water is a great way to start any foot-care regime. By taking a sturdy bowl or bucket, full half way with warm water and leave the feet soak for around 10 minutes. Remove from the water and pat dry with a soft and clean towel."};
    Integer im[]={R.drawable.lemon3,R.drawable.lemon2,R.drawable.feet};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arm2);
        ta1=(TextView)findViewById(R.id.ta1);
        ima=(ImageView)findViewById(R.id.ima);
        b1=(Button)findViewById(R.id.b1);
        wv=(WebView)findViewById(R.id.wv);
        Intent in=getIntent();
        int a= in.getIntExtra("poss",0);
        String b=in.getStringExtra("name");
        ta1.setText(dis[a]);
        ima.setImageResource(im[a]);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent in = new Intent(arm2.this, armvideo.class);
                //startActivity(in);

                wv.loadUrl("https://youtu.be/xEt0sDfULt8");
            }
        });

    }
}
